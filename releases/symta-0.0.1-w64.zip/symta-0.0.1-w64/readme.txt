Ensure you have mingw64 installed and gcc is in your path



Run "run.exe -h" to find options.
